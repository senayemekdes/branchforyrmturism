import "./styles.css";
//import Caredforall from "./components/Caredforall"; // this is for cards of attraction
//import Cardol from "./components/Carsol"; // for the slide of the image at the top
//import Description from "./components/DescriptioMelisa"; // description is for paragraph
//import Image from "./components/Image";
//import DescriptioAbo from "./components/DescriptioAbo";
//import DescriptioBirbirsa from "./components/DescriptioBirbirsa";
//import DescriptioBortera from "./components/DescriptioBortera";
//import DescriptioChalo from "./components/DescriptioChalo";
import DescriptioKurumni from "./components/DescriptioKurumni";
import DescriptioMelisa from "./components/DescriptioMelisa";
import Descriptiowoma from "./components/Descriptiowoma";
import DescriptioTinatawit from "./components/DescriptioTinatawit";
import DescriptioZofkar from "./components/DescriptioZofkar";
import DescriptioFofa from "./components/DescriptioFofa";
export default function App() {
  return (
    <div className="App">
      <DescriptioFofa />

      {/* <Cardol />  
<DescriptioAbo />
      <Image
        cName="hero"
        title="Here’s the places you must visit!"
        text="Tour givs you the opportunity to discover about the place!!"
        heroImg="https://images.unsplash.com/photo-1693287528551-b3c3a6b28843?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80"
      />
      <Description />*/}
    </div>
  );
}
